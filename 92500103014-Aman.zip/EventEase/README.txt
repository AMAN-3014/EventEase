EventEase - Web Technology Project

Open Client/1- Home Page.html to start the website.
Open Admin/1- Login Page.html for the admin panel.
Demo admin login: admin / admin123

Shared files: css/, js/, images/
Project documents:
1. Project_Wireframe.pdf
2. Client Side - Web Pages.pdf
3. Admin Side - Web Pages.pdf
4. JS Validation.pdf
